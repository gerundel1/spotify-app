import { ArrayType } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import * as data from '../data/NewReleasesAlbums.json';


@Component({
  selector: 'app-new-releases',
  templateUrl: './new-releases.component.html',
  styleUrls: ['./new-releases.component.css']
})

export class NewReleasesComponent implements OnInit {

  releases: typeof data.albums.items;

  constructor() { 
    this.releases = [];
  }

  ngOnInit(): void {
    this.releases = data.albums.items;
  }

}
